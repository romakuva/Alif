<?php

include_once __DIR__ . "/../Test/OrderServiceTest.php";

$test = new OrderServiceTest();

$test->testCalcTotal();

die ("OK");
