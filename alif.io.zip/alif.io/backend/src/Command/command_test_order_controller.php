<?php

include_once __DIR__ . "/../Test/OrderControllerTest.php";

$test = new OrderControllerTest();

$test->testCreate();

die ("OK");
