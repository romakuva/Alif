<?php
    include_once __DIR__ . "/../header.php";
?>

<div style="padding: 100px 0px;">
    <div style="font-size: 50px; text-align: center;"><?=$code?></div>
    <div style="text-align: center;"><?=$message?></div>
</div>

<?php
    include_once __DIR__ . "/../footer.php";
?>