</div>
    <footer>
        <nav class="width1024">
            <div class="categories-group">
                <h4>Biography & True Stories</h4>
                <ul>
                    <li><a href="#">Children</a></li>
                    <li><a href="#">Science Fiction</a></li>
                    <li><a href="#">Fantasy</a></li>
                    <li><a href="#">Mystery</a></li>
                    <li><a href="#">Romance</a></li>
                    <li><a href="#">Horror</a></li>
                    <li><a href="#">Poetry</a></li>
                    <li><a href="#">Literature</a></li>
                    <li><a href="#">Crime</a></li>
                </ul>
            </div>
            <div class="categories-group">
                <h4>Professional & Reference</h4>
                <ul>
                    <li><a href="#">Children</a></li>
                    <li><a href="#">Science Fiction</a></li>
                    <li><a href="#">Fantasy</a></li>
                    <li><a href="#">Mystery</a></li>
                    <li><a href="#">Romance</a></li>
                    <li><a href="#">Horror</a></li>
                    <li><a href="#">Poetry</a></li>
                    <li><a href="#">Literature</a></li>
                    <li><a href="#">Crime</a></li>
                </ul>
            </div>
            <div class="categories-group">
                <h4>Earth Sciences</h4>
                <ul>
                    <li><a href="#">Children</a></li>
                    <li><a href="#">Science Fiction</a></li>
                    <li><a href="#">Fantasy</a></li>
                    <li><a href="#">Mystery</a></li>
                    <li><a href="#">Romance</a></li>
                    <li><a href="#">Horror</a></li>
                    <li><a href="#">Poetry</a></li>
                    <li><a href="#">Literature</a></li>
                    <li><a href="#">Crime</a></li>
                </ul>
            </div>
            <div class="categories-group">
                <h4>Mathematics</h4>
                <ul>
                    <li><a href="#">Children</a></li>
                    <li><a href="#">Science Fiction</a></li>
                    <li><a href="#">Fantasy</a></li>
                    <li><a href="#">Mystery</a></li>
                    <li><a href="#">Romance</a></li>
                    <li><a href="#">Horror</a></li>
                    <li><a href="#">Poetry</a></li>
                    <li><a href="#">Literature</a></li>
                    <li><a href="#">Crime</a></li>
                </ul>
            </div>
        </nav>
        <div id="payments-system">
            <div>We accept all major Credit Cart/Debit Cart/Internet Banking</div>
            <div><img src="img/payments01.jpg"><img src="img/payments02.jpg"><img src="img/payments03.jpg"></div>
        </div>
        <div class="info">
            Conditions of Use Privacy Notice © 2012-2013, Booksonline, Inc
        </div>
    </footer>
</body>
</html>